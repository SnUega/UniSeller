# 🚀 Финальная инструкция по запуску проекта

## Что изменилось в этой версии

✅ **Aurora gradient** - добавлен WebGL градиент с OGL
✅ **DotsPlane** - каждая точка реагирует на курсор индивидуально
✅ **Carousel** - ускорен до 12 секунд, на всю ширину экрана
✅ **Hero padding-bottom** - добавлено 100px чтобы dashboard не обрезался

## Установка и запуск

### 1. Установите зависимости

```bash
npm install
```

Это установит `ogl` пакет для Aurora gradient.

### 2. Запустите dev server

```bash
npm run dev
```

## Что нужно сделать с шрифтами

**Шрифты PP Mori и Benzin не загружаются с CDN!**

### Вариант A: Скачать и добавить локально (рекомендуется)
Следуйте инструкции в файле **`FONTS_INSTALLATION.md`**

### Вариант B: Использовать Google Fonts альтернативы
В `index.html` замените:
```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Bebas+Neue&display=swap" rel="stylesheet">
```

В CSS файлах замените:
- `'PP Mori'` → `'Inter'`
- `'Benzin'` → `'Bebas Neue'`

## Структура компонентов

```
src/components/
├── AppHeader.vue          # Хедер
├── HeroSection.vue        # Главная секция (использует Aurora + DotsPlane)
├── AuroraBackground.vue   # NEW! WebGL gradient
├── DotsPlane.vue          # NEW! Интерактивные точки
├── MarketplacesSection.vue # Карусель логотипов
├── StatsSection.vue       # Статистика
└── AppFooter.vue          # Футер
```

## Проверка работы

1. **Aurora gradient**: Должен быть анимированный оранжевый градиент на фоне
2. **Dots**: При наведении курсора точки должны увеличиваться
3. **Carousel**: Логотипы должны плавно двигаться на всю ширину экрана
4. **Dashboard**: Не должен обрезаться снизу

## Если что-то не работает

### Aurora не отображается
```bash
# Проверьте что ogl установлен:
npm list ogl

# Если нет, установите:
npm install ogl

# Перезапустите:
npm run dev
```

### Dots лагают
Уменьшите количество точек в `DotsPlane.vue`:
```javascript
const cols = Math.ceil(window.innerWidth / spacing) + 5 // было +10
const rows = 50 // было 65
```

### Шрифты не те
Смотрите **FONTS_INSTALLATION.md**

## Следующие шаги

Теперь можно добавлять остальные секции страницы! 🎉
